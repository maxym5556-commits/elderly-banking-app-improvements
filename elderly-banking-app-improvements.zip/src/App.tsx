import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Home, Send, Receipt, Mic, MoreHorizontal, Zap, Droplets, Flame,
  Wifi, Smartphone, Shield, Stethoscope, CheckCircle2, ScanFace,
  Globe, Volume2, VolumeX, ChevronRight, ArrowLeft, Phone,
  AlertCircle, IndianRupee, CircleDot, Fingerprint, User, Lock,
  Eye, EyeOff, LogOut, Video, PhoneCall, Clock, ShieldCheck,
  Star, Headphones, ChevronDown, Sparkles,
} from "lucide-react";
import { translations, languageNames, languageFlags, speechLangs, type Language, type Translations } from "./translations";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

type Screen = "home" | "pay" | "bills" | "assistant" | "more";
type AuthScreen = "login" | "otp" | "fingerprint" | "face" | "app";

interface Transaction {
  id: string;
  title: string;
  amount: number;
  date: string;
  type: "sent" | "received";
}

interface BillCategory {
  key: string;
  icon: React.ReactNode;
  color: string;
}

/* ------------------------------------------------------------------ */
/*  Mock Data                                                          */
/* ------------------------------------------------------------------ */

const MOCK_TRANSACTIONS: Transaction[] = [
  { id: "1", title: "Electricity Bill", amount: 1240, date: "Today", type: "sent" },
  { id: "2", title: "Pension Credit", amount: 15000, date: "Yesterday", type: "received" },
  { id: "3", title: "Mobile Recharge", amount: 399, date: "2 days ago", type: "sent" },
  { id: "4", title: "Gas Bill", amount: 850, date: "3 days ago", type: "sent" },
];

/* ------------------------------------------------------------------ */
/*  Voice Hook                                                         */
/* ------------------------------------------------------------------ */

function useVoice(lang: Language) {
  const speak = useCallback(
    (text: string, rate = 0.7) => {
      if (typeof window === "undefined" || !window.speechSynthesis) return;
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      utter.lang = speechLangs[lang] || "en-IN";
      utter.rate = rate;
      utter.pitch = 1;
      window.speechSynthesis.speak(utter);
    },
    [lang]
  );

  const stop = useCallback(() => {
    if (typeof window !== "undefined" && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
  }, []);

  return { speak, stop };
}

/* ------------------------------------------------------------------ */
/*  Face ID Overlay                                                    */
/* ------------------------------------------------------------------ */

function FaceIDOverlay({
  t,
  onSuccess,
  onCancel,
  speak,
  mode = "payment",
}: {
  t: Translations;
  onSuccess: () => void;
  onCancel: () => void;
  speak: (text: string) => void;
  mode?: "payment" | "login";
}) {
  const [phase, setPhase] = useState<"scanning" | "recognized" | "success">("scanning");
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    speak(t.pleaseLookAtCamera);
    const timer1 = setTimeout(() => setPhase("recognized"), 2500);
    const timer2 = setTimeout(() => {
      setPhase("success");
      speak(mode === "login" ? t.authSuccess : t.paymentSuccessful);
    }, 3800);
    const timer3 = setTimeout(() => onSuccess(), 5200);
    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, [t, onSuccess, speak, mode]);

  useEffect(() => {
    navigator.mediaDevices
      ?.getUserMedia({ video: { facingMode: "user" } })
      .then((stream) => {
        if (videoRef.current) videoRef.current.srcObject = stream;
      })
      .catch(() => {});
    return () => {
      if (videoRef.current?.srcObject) {
        (videoRef.current.srcObject as MediaStream).getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/90 p-6"
    >
      <div className="relative mb-8 h-64 w-64 overflow-hidden rounded-full border-4 border-white/20">
        <video ref={videoRef} autoPlay playsInline muted className="h-full w-full object-cover" />
        {phase === "scanning" && (
          <motion.div
            className="absolute inset-0 rounded-full border-4 border-emerald-400"
            animate={{ opacity: [0.3, 1, 0.3] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
        )}
        {phase === "recognized" && (
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="absolute inset-0 flex items-center justify-center rounded-full bg-emerald-500/30"
          >
            <ScanFace className="h-20 w-20 text-emerald-300" />
          </motion.div>
        )}
        {phase === "success" && (
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="absolute inset-0 flex items-center justify-center rounded-full bg-emerald-500/40"
          >
            <CheckCircle2 className="h-24 w-24 text-white" />
          </motion.div>
        )}
        {phase === "scanning" && (
          <motion.div
            className="absolute left-0 right-0 h-1 bg-emerald-400 shadow-[0_0_15px_rgba(52,211,153,0.8)]"
            animate={{ top: ["0%", "100%", "0%"] }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          />
        )}
      </div>
      <h2 className="mb-2 text-center text-3xl font-bold text-white">
        {phase === "scanning" && t.scanningFace}
        {phase === "recognized" && t.faceRecognized}
        {phase === "success" && (mode === "login" ? t.authSuccess : t.paymentSuccessful)}
      </h2>
      <p className="mb-8 text-center text-xl text-white/70">
        {phase === "scanning" && t.holdSteady}
        {phase === "recognized" && t.pleaseConfirm}
        {phase === "success" && t.thankYou}
      </p>
      {phase !== "success" && (
        <button
          onClick={onCancel}
          className="rounded-2xl bg-white/10 px-8 py-4 text-xl font-semibold text-white active:bg-white/20"
        >
          {t.cancel}
        </button>
      )}
    </motion.div>
  );
}

/* ------------------------------------------------------------------ */
/*  Fingerprint Overlay                                                */
/* ------------------------------------------------------------------ */

function FingerprintOverlay({
  t,
  onSuccess,
  onCancel,
  speak,
  mode = "payment",
}: {
  t: Translations;
  onSuccess: () => void;
  onCancel: () => void;
  speak: (text: string) => void;
  mode?: "payment" | "login";
}) {
  const [phase, setPhase] = useState<"scanning" | "recognized" | "success">("scanning");
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    speak(t.placeFinger);
    const prog = setInterval(() => setProgress((p) => Math.min(p + 4, 100)), 80);
    const timer1 = setTimeout(() => setPhase("recognized"), 2200);
    const timer2 = setTimeout(() => {
      setPhase("success");
      speak(mode === "login" ? t.authSuccess : t.paymentSuccessful);
    }, 3500);
    const timer3 = setTimeout(() => onSuccess(), 4800);
    return () => {
      clearInterval(prog);
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, [t, onSuccess, speak, mode]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/90 p-6"
    >
      <div className="relative mb-8 flex h-56 w-56 items-center justify-center rounded-3xl border-4 border-white/20 bg-white/5">
        <Fingerprint className={`h-28 w-28 ${phase === "success" ? "text-emerald-400" : "text-white/60"}`} />
        {phase === "scanning" && (
          <svg className="absolute inset-0 h-full w-full" viewBox="0 0 224 224">
            <circle
              cx="112" cy="112" r="100"
              fill="none" stroke="rgba(52,211,153,0.3)" strokeWidth="6"
            />
            <motion.circle
              cx="112" cy="112" r="100"
              fill="none" stroke="#34d399" strokeWidth="6"
              strokeDasharray={628}
              strokeDashoffset={628 - (628 * progress) / 100}
              strokeLinecap="round"
              transform="rotate(-90 112 112)"
            />
          </svg>
        )}
        {phase === "recognized" && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute inset-0 flex items-center justify-center rounded-3xl bg-emerald-500/20"
          >
            <CheckCircle2 className="h-20 w-20 text-emerald-400" />
          </motion.div>
        )}
        {phase === "success" && (
          <motion.div
            initial={{ scale: 0.5 }}
            animate={{ scale: 1 }}
            className="absolute inset-0 flex items-center justify-center rounded-3xl bg-emerald-500/30"
          >
            <CheckCircle2 className="h-24 w-24 text-white" />
          </motion.div>
        )}
      </div>
      <h2 className="mb-2 text-center text-3xl font-bold text-white">
        {phase === "scanning" && t.fingerprintScanning}
        {phase === "recognized" && t.fingerprintRecognized}
        {phase === "success" && (mode === "login" ? t.authSuccess : t.fingerprintSuccess)}
      </h2>
      <p className="mb-8 text-center text-xl text-white/70">
        {phase === "scanning" && t.placeFinger}
        {phase === "recognized" && t.pleaseConfirm}
        {phase === "success" && t.thankYou}
      </p>
      {phase !== "success" && (
        <button
          onClick={onCancel}
          className="rounded-2xl bg-white/10 px-8 py-4 text-xl font-semibold text-white active:bg-white/20"
        >
          {t.cancel}
        </button>
      )}
    </motion.div>
  );
}

/* ------------------------------------------------------------------ */
/*  Login Screen                                                       */
/* ------------------------------------------------------------------ */

function LoginScreen({
  t,
  lang,
  setLang,
  speak,
  onLogin,
}: {
  t: Translations;
  lang: Language;
  setLang: (l: Language) => void;
  speak: (text: string) => void;
  onLogin: (method: "pin" | "face" | "fingerprint") => void;
}) {
  const [phone, setPhone] = useState("");
  const [pin, setPin] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [showLang, setShowLang] = useState(false);
  const [showFace, setShowFace] = useState(false);
  const [showFinger, setShowFinger] = useState(false);

  useEffect(() => {
    speak(`${t.welcomeBack}. ${t.enterPhone}.`);
  }, [t, speak]);

  const handleLogin = () => {
    if (phone.length >= 10 && pin.length === 4) {
      speak(t.authSuccess);
      onLogin("pin");
    }
  };

  const handleFaceLogin = () => {
    setShowFace(true);
  };

  const handleFingerLogin = () => {
    setShowFinger(true);
  };

  return (
    <div className="flex min-h-screen flex-col bg-[#FFF8F0] px-5 py-8">
      {/* Language Switcher */}
      <div className="mb-6 flex justify-end">
        <button
          onClick={() => setShowLang(!showLang)}
          className="flex items-center gap-2 rounded-2xl bg-white px-4 py-2 text-lg font-bold text-slate-700 shadow-md"
        >
          <Globe className="h-5 w-5" />
          {languageFlags[lang]} {languageNames[lang]}
          <ChevronDown className="h-4 w-4" />
        </button>
      </div>
      <AnimatePresence>
        {showLang && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mb-4 space-y-2"
          >
            {(Object.keys(languageNames) as Language[]).map((l) => (
              <button
                key={l}
                onClick={() => {
                  setLang(l);
                  setShowLang(false);
                  speak(`${translations[l].languageChanged} ${languageNames[l]}`);
                }}
                className={`flex w-full items-center gap-3 rounded-2xl border-2 px-5 py-3 text-xl font-bold transition-all ${
                  lang === l ? "border-teal-500 bg-teal-50 text-teal-800" : "border-slate-200 bg-white text-slate-700"
                }`}
              >
                <span className="text-2xl">{languageFlags[l]}</span>
                <span>{languageNames[l]}</span>
                {lang === l && <CheckCircle2 className="ml-auto h-5 w-5 text-teal-600" />}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Welcome */}
      <div className="mb-8 text-center">
        <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-3xl bg-teal-700 text-white shadow-xl">
          <ShieldCheck className="h-10 w-10" />
        </div>
        <h1 className="text-3xl font-bold text-slate-900">{t.appName}</h1>
        <p className="mt-2 text-xl text-slate-500">{t.welcomeBack}</p>
      </div>

      {/* Login Form */}
      <div className="space-y-5">
        <div className="rounded-3xl bg-white p-6 shadow-xl">
          <div className="mb-5">
            <label className="mb-2 block text-xl font-bold text-slate-700">{t.phoneNumber}</label>
            <div className="flex items-center gap-3 rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-4 focus-within:border-teal-500">
              <Phone className="h-6 w-6 text-slate-400" />
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
                placeholder={t.enterPhone}
                className="w-full bg-transparent text-2xl font-bold text-slate-900 placeholder:text-slate-400 focus:outline-none"
              />
            </div>
          </div>
          <div>
            <label className="mb-2 block text-xl font-bold text-slate-700">{t.enterPin}</label>
            <div className="flex items-center gap-3 rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-4 focus-within:border-teal-500">
              <Lock className="h-6 w-6 text-slate-400" />
              <input
                type={showPin ? "text" : "password"}
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
                placeholder="••••"
                className="w-full bg-transparent text-3xl font-bold text-slate-900 placeholder:text-slate-400 focus:outline-none tracking-[0.3em]"
              />
              <button onClick={() => setShowPin(!showPin)} className="text-slate-400">
                {showPin ? <EyeOff className="h-6 w-6" /> : <Eye className="h-6 w-6" />}
              </button>
            </div>
          </div>
          <div className="mt-4 flex items-center justify-between">
            <label className="flex items-center gap-2 text-lg font-semibold text-slate-600">
              <input type="checkbox" className="h-5 w-5 rounded border-slate-300 text-teal-600" />
              {t.rememberMe}
            </label>
            <button className="text-lg font-semibold text-teal-700">{t.forgotPin}</button>
          </div>
        </div>

        <button
          onClick={handleLogin}
          disabled={phone.length < 10 || pin.length < 4}
          className="flex w-full items-center justify-center gap-3 rounded-2xl bg-teal-700 py-5 text-2xl font-bold text-white shadow-lg disabled:opacity-40 active:scale-[0.98] transition-transform"
        >
          <Lock className="h-7 w-7" />
          {t.loginButton}
        </button>

        <div className="flex items-center gap-4">
          <div className="h-px flex-1 bg-slate-300" />
          <span className="text-lg font-semibold text-slate-400">{t.orUse}</span>
          <div className="h-px flex-1 bg-slate-300" />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={handleFaceLogin}
            className="flex flex-col items-center gap-2 rounded-2xl bg-white p-5 shadow-md active:scale-95 transition-transform"
          >
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-violet-100 text-violet-700">
              <ScanFace className="h-8 w-8" />
            </div>
            <span className="text-lg font-bold text-slate-800">{t.useFaceId}</span>
          </button>
          <button
            onClick={handleFingerLogin}
            className="flex flex-col items-center gap-2 rounded-2xl bg-white p-5 shadow-md active:scale-95 transition-transform"
          >
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-100 text-amber-700">
              <Fingerprint className="h-8 w-8" />
            </div>
            <span className="text-lg font-bold text-slate-800">{t.useFingerprint}</span>
          </button>
        </div>
      </div>

      {/* Security badges */}
      <div className="mt-auto pt-8">
        <div className="flex items-center justify-center gap-6 text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5" />
            <span className="text-sm font-semibold">{t.bankGradeSecurity}</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5" />
            <span className="text-sm font-semibold">{t.npciCertified}</span>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showFace && (
          <FaceIDOverlay
            t={t}
            mode="login"
            onCancel={() => setShowFace(false)}
            onSuccess={() => onLogin("face")}
            speak={speak}
          />
        )}
        {showFinger && (
          <FingerprintOverlay
            t={t}
            mode="login"
            onCancel={() => setShowFinger(false)}
            onSuccess={() => onLogin("fingerprint")}
            speak={speak}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Home Screen                                                        */
/* ------------------------------------------------------------------ */

function HomeScreen({
  t,
  speak,
  onNavigate,
}: {
  t: Translations;
  speak: (text: string) => void;
  onNavigate: (s: Screen) => void;
}) {
  useEffect(() => {
    speak(`${t.welcome}. ${t.yourBalanceIs} 24,789 ${t.rupees}.`);
  }, [t, speak]);

  return (
    <div className="space-y-6 pb-24">
      {/* Greeting */}
      <div className="px-4 pt-4">
        <p className="text-xl text-slate-500">{t.welcome}</p>
        <h1 className="text-3xl font-bold text-slate-900">{t.appName}</h1>
      </div>

      {/* Balance Card */}
      <div className="mx-4 rounded-3xl bg-gradient-to-br from-teal-600 to-teal-800 p-6 text-white shadow-xl">
        <p className="mb-2 text-lg opacity-90">{t.availableBalance}</p>
        <div className="flex items-baseline gap-1">
          <IndianRupee className="h-8 w-8" />
          <span className="text-5xl font-bold tracking-tight">24,789</span>
        </div>
        <p className="mt-2 text-base opacity-80">{t.rupees}</p>
      </div>

      {/* Quick Actions */}
      <div className="px-4">
        <h2 className="mb-4 text-2xl font-bold text-slate-900">{t.quickActions}</h2>
        <div className="grid grid-cols-3 gap-4">
          {[
            { label: t.transferMoney, icon: <Send className="h-8 w-8" />, screen: "pay" as Screen, color: "bg-amber-500" },
            { label: t.payBills, icon: <Receipt className="h-8 w-8" />, screen: "bills" as Screen, color: "bg-rose-500" },
            { label: t.voiceHelp, icon: <Mic className="h-8 w-8" />, screen: "assistant" as Screen, color: "bg-violet-500" },
          ].map((action) => (
            <button
              key={action.label}
              onClick={() => onNavigate(action.screen)}
              className="flex flex-col items-center gap-3 rounded-2xl bg-white p-5 shadow-md active:scale-95 transition-transform"
            >
              <div className={`flex h-14 w-14 items-center justify-center rounded-2xl ${action.color} text-white shadow-lg`}>
                {action.icon}
              </div>
              <span className="text-center text-base font-semibold leading-tight text-slate-800">{action.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* PhonePe Social Proof */}
      <div className="mx-4 rounded-3xl bg-gradient-to-r from-indigo-600 to-violet-700 p-5 text-white shadow-xl">
        <div className="flex items-center gap-3 mb-3">
          <div className="flex -space-x-3">
            {[0,1,2,3].map((i) => (
              <div key={i} className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-white bg-white/20 text-sm font-bold">
                {["👴","👵","👨","👩"][i]}
              </div>
            ))}
          </div>
          <div>
            <p className="text-lg font-bold">{t.trustedByMillions}</p>
            <p className="text-sm opacity-80">{t.peopleUsingPhonePe}</p>
          </div>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1">
            <ShieldCheck className="h-4 w-4" />
            <span>{t.bankSecure}</span>
          </div>
          <div className="flex items-center gap-1">
            <CheckCircle2 className="h-4 w-4" />
            <span>{t.npciCertified}</span>
          </div>
          <div className="flex items-center gap-1">
            <Star className="h-4 w-4" />
            <span>4.9★</span>
          </div>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="px-4">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-slate-900">{t.recentTransactions}</h2>
          <button className="text-lg font-semibold text-teal-700">{t.viewAll}</button>
        </div>
        <div className="space-y-3">
          {MOCK_TRANSACTIONS.map((tx) => (
            <div
              key={tx.id}
              className="flex items-center justify-between rounded-2xl bg-white p-5 shadow-md"
            >
              <div className="flex items-center gap-4">
                <div
                  className={`flex h-12 w-12 items-center justify-center rounded-xl ${
                    tx.type === "received" ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"
                  }`}
                >
                  {tx.type === "received" ? <IndianRupee className="h-6 w-6" /> : <Send className="h-6 w-6" />}
                </div>
                <div>
                  <p className="text-lg font-bold text-slate-900">{tx.title}</p>
                  <p className="text-base text-slate-500">{tx.date}</p>
                </div>
              </div>
              <p className={`text-xl font-bold ${tx.type === "received" ? "text-emerald-700" : "text-slate-900"}`}>
                {tx.type === "received" ? "+" : "-"}₹{tx.amount.toLocaleString()}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Pay Screen                                                         */
/* ------------------------------------------------------------------ */

function PayScreen({
  t,
  speak,
  onBack,
}: {
  t: Translations;
  speak: (text: string) => void;
  onBack: () => void;
}) {
  const [amount, setAmount] = useState("");
  const [recipient, setRecipient] = useState("");
  const [showFaceID, setShowFaceID] = useState(false);
  const [showFinger, setShowFinger] = useState(false);
  const [paymentDone, setPaymentDone] = useState(false);
  const [authMethod, setAuthMethod] = useState<"face" | "fingerprint">("face");

  const handlePay = () => {
    if (!amount || !recipient) return;
    if (authMethod === "face") {
      speak(t.pleaseLookAtCamera);
      setShowFaceID(true);
    } else {
      speak(t.placeFinger);
      setShowFinger(true);
    }
  };

  return (
    <div className="space-y-6 pb-24">
      <div className="flex items-center gap-4 px-4 pt-4">
        <button onClick={onBack} className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white shadow-md active:scale-95">
          <ArrowLeft className="h-6 w-6 text-slate-700" />
        </button>
        <h1 className="text-3xl font-bold text-slate-900">{t.transferMoney}</h1>
      </div>

      {!paymentDone ? (
        <>
          <div className="mx-4 space-y-6 rounded-3xl bg-white p-6 shadow-xl">
            <div>
              <label className="mb-2 block text-xl font-bold text-slate-700">{t.to}</label>
              <input
                type="text"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                placeholder={t.recipient}
                className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-4 text-xl font-semibold text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-2 block text-xl font-bold text-slate-700">{t.amount}</label>
              <div className="flex items-center gap-3 rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-4 focus-within:border-teal-500">
                <IndianRupee className="h-7 w-7 text-slate-500" />
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0"
                  className="w-full bg-transparent text-3xl font-bold text-slate-900 placeholder:text-slate-400 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Auth Method Selection */}
          <div className="mx-4 rounded-3xl bg-white p-5 shadow-xl">
            <p className="mb-3 text-lg font-bold text-slate-700">{t.loginOptions}</p>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setAuthMethod("face")}
                className={`flex items-center gap-3 rounded-2xl border-2 px-4 py-3 text-lg font-bold transition-all ${
                  authMethod === "face" ? "border-violet-500 bg-violet-50 text-violet-800" : "border-slate-200 bg-slate-50 text-slate-600"
                }`}
              >
                <ScanFace className="h-6 w-6" />
                {t.useFaceId}
              </button>
              <button
                onClick={() => setAuthMethod("fingerprint")}
                className={`flex items-center gap-3 rounded-2xl border-2 px-4 py-3 text-lg font-bold transition-all ${
                  authMethod === "fingerprint" ? "border-amber-500 bg-amber-50 text-amber-800" : "border-slate-200 bg-slate-50 text-slate-600"
                }`}
              >
                <Fingerprint className="h-6 w-6" />
                {t.useFingerprint}
              </button>
            </div>
          </div>

          <div className="px-4">
            <button
              onClick={handlePay}
              disabled={!amount || !recipient}
              className="flex w-full items-center justify-center gap-3 rounded-2xl bg-teal-700 py-5 text-2xl font-bold text-white shadow-lg disabled:opacity-40 active:scale-[0.98] transition-transform"
            >
              {authMethod === "face" ? <ScanFace className="h-8 w-8" /> : <Fingerprint className="h-8 w-8" />}
              {authMethod === "face" ? t.payWithFace : t.payWithFingerprint}
            </button>
          </div>
        </>
      ) : (
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="mx-4 flex flex-col items-center rounded-3xl bg-white p-10 shadow-xl"
        >
          <div className="mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-emerald-100">
            <CheckCircle2 className="h-14 w-14 text-emerald-600" />
          </div>
          <h2 className="mb-2 text-3xl font-bold text-slate-900">{t.paymentSuccessful}</h2>
          <p className="mb-8 text-center text-xl text-slate-500">
            ₹{Number(amount).toLocaleString()} {t.sent.toLowerCase()} {t.to} {recipient}
          </p>
          <button
            onClick={onBack}
            className="w-full rounded-2xl bg-teal-700 py-4 text-2xl font-bold text-white shadow-lg active:scale-[0.98]"
          >
            {t.done}
          </button>
        </motion.div>
      )}

      <AnimatePresence>
        {showFaceID && (
          <FaceIDOverlay
            t={t}
            onCancel={() => setShowFaceID(false)}
            onSuccess={() => { setShowFaceID(false); setPaymentDone(true); }}
            speak={speak}
          />
        )}
        {showFinger && (
          <FingerprintOverlay
            t={t}
            onCancel={() => setShowFinger(false)}
            onSuccess={() => { setShowFinger(false); setPaymentDone(true); }}
            speak={speak}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Bills Screen                                                       */
/* ------------------------------------------------------------------ */

function BillsScreen({
  t,
  speak,
  onBack,
}: {
  t: Translations;
  speak: (text: string) => void;
  onBack: () => void;
}) {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [billNumber, setBillNumber] = useState("");
  const [billAmount, setBillAmount] = useState("");
  const [showFaceID, setShowFaceID] = useState(false);
  const [showFinger, setShowFinger] = useState(false);
  const [paymentDone, setPaymentDone] = useState(false);
  const [authMethod, setAuthMethod] = useState<"face" | "fingerprint">("face");

  const categories: BillCategory[] = [
    { key: "electricity", icon: <Zap className="h-10 w-10" />, color: "bg-amber-500" },
    { key: "water", icon: <Droplets className="h-10 w-10" />, color: "bg-sky-500" },
    { key: "gas", icon: <Flame className="h-10 w-10" />, color: "bg-orange-500" },
    { key: "internet", icon: <Wifi className="h-10 w-10" />, color: "bg-indigo-500" },
    { key: "mobile", icon: <Smartphone className="h-10 w-10" />, color: "bg-violet-500" },
    { key: "insurance", icon: <Shield className="h-10 w-10" />, color: "bg-emerald-500" },
    { key: "medical", icon: <Stethoscope className="h-10 w-10" />, color: "bg-rose-500" },
  ];

  const handlePayBill = () => {
    if (!billNumber || !billAmount) return;
    if (authMethod === "face") {
      speak(t.pleaseLookAtCamera);
      setShowFaceID(true);
    } else {
      speak(t.placeFinger);
      setShowFinger(true);
    }
  };

  const getLabel = (key: string) => {
    const map: Record<string, string> = {
      electricity: t.electricity, water: t.water, gas: t.gas,
      internet: t.internet, mobile: t.mobile, insurance: t.insurance, medical: t.medical,
    };
    return map[key] || key;
  };

  if (paymentDone) {
    return (
      <div className="space-y-6 pb-24">
        <div className="flex items-center gap-4 px-4 pt-4">
          <button onClick={onBack} className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white shadow-md active:scale-95">
            <ArrowLeft className="h-6 w-6 text-slate-700" />
          </button>
          <h1 className="text-3xl font-bold text-slate-900">{t.billPayment}</h1>
        </div>
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="mx-4 flex flex-col items-center rounded-3xl bg-white p-10 shadow-xl"
        >
          <div className="mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-emerald-100">
            <CheckCircle2 className="h-14 w-14 text-emerald-600" />
          </div>
          <h2 className="mb-2 text-3xl font-bold text-slate-900">{t.paymentSuccessful}</h2>
          <p className="mb-8 text-center text-xl text-slate-500">
            {t.payingBill} {getLabel(selectedCategory || "")} {t.bill}
          </p>
          <button onClick={onBack} className="w-full rounded-2xl bg-teal-700 py-4 text-2xl font-bold text-white shadow-lg active:scale-[0.98]">
            {t.done}
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-24">
      <div className="flex items-center gap-4 px-4 pt-4">
        <button onClick={onBack} className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white shadow-md active:scale-95">
          <ArrowLeft className="h-6 w-6 text-slate-700" />
        </button>
        <h1 className="text-3xl font-bold text-slate-900">{t.billPayment}</h1>
      </div>

      {!selectedCategory ? (
        <div className="px-4">
          <h2 className="mb-4 text-2xl font-bold text-slate-700">{t.selectBillType}</h2>
          <div className="grid grid-cols-2 gap-4">
            {categories.map((cat) => (
              <button
                key={cat.key}
                onClick={() => {
                  setSelectedCategory(cat.key);
                  speak(`${getLabel(cat.key)} ${t.bill} ${t.selectBillType}`);
                }}
                className="flex flex-col items-center gap-4 rounded-2xl bg-white p-6 shadow-md active:scale-95 transition-transform"
              >
                <div className={`flex h-16 w-16 items-center justify-center rounded-2xl ${cat.color} text-white shadow-lg`}>
                  {cat.icon}
                </div>
                <span className="text-center text-lg font-bold text-slate-800">{getLabel(cat.key)}</span>
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="mx-4 space-y-6">
          <div className="rounded-3xl bg-white p-6 shadow-xl">
            <div className="mb-6 flex items-center gap-3">
              <button onClick={() => setSelectedCategory(null)} className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100">
                <ArrowLeft className="h-5 w-5 text-slate-600" />
              </button>
              <h2 className="text-2xl font-bold text-slate-900">{getLabel(selectedCategory)} {t.bill}</h2>
            </div>
            <div className="space-y-5">
              <div>
                <label className="mb-2 block text-xl font-bold text-slate-700">{t.billNumber}</label>
                <input
                  type="text" value={billNumber} onChange={(e) => setBillNumber(e.target.value)}
                  className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-4 text-xl font-semibold text-slate-900 focus:border-teal-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-2 block text-xl font-bold text-slate-700">{t.amount}</label>
                <div className="flex items-center gap-3 rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-4 focus-within:border-teal-500">
                  <IndianRupee className="h-7 w-7 text-slate-500" />
                  <input type="number" value={billAmount} onChange={(e) => setBillAmount(e.target.value)} placeholder="0"
                    className="w-full bg-transparent text-3xl font-bold text-slate-900 placeholder:text-slate-400 focus:outline-none"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Auth Method Selection */}
          <div className="rounded-3xl bg-white p-5 shadow-xl">
            <p className="mb-3 text-lg font-bold text-slate-700">{t.loginOptions}</p>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setAuthMethod("face")}
                className={`flex items-center gap-3 rounded-2xl border-2 px-4 py-3 text-lg font-bold transition-all ${
                  authMethod === "face" ? "border-violet-500 bg-violet-50 text-violet-800" : "border-slate-200 bg-slate-50 text-slate-600"
                }`}
              >
                <ScanFace className="h-6 w-6" />
                {t.useFaceId}
              </button>
              <button
                onClick={() => setAuthMethod("fingerprint")}
                className={`flex items-center gap-3 rounded-2xl border-2 px-4 py-3 text-lg font-bold transition-all ${
                  authMethod === "fingerprint" ? "border-amber-500 bg-amber-50 text-amber-800" : "border-slate-200 bg-slate-50 text-slate-600"
                }`}
              >
                <Fingerprint className="h-6 w-6" />
                {t.useFingerprint}
              </button>
            </div>
          </div>

          <button
            onClick={handlePayBill}
            disabled={!billNumber || !billAmount}
            className="flex w-full items-center justify-center gap-3 rounded-2xl bg-teal-700 py-5 text-2xl font-bold text-white shadow-lg disabled:opacity-40 active:scale-[0.98] transition-transform"
          >
            {authMethod === "face" ? <ScanFace className="h-8 w-8" /> : <Fingerprint className="h-8 w-8" />}
            {t.payBill}
          </button>
        </div>
      )}

      <AnimatePresence>
        {showFaceID && (
          <FaceIDOverlay t={t} onCancel={() => setShowFaceID(false)} onSuccess={() => { setShowFaceID(false); setPaymentDone(true); }} speak={speak} />
        )}
        {showFinger && (
          <FingerprintOverlay t={t} onCancel={() => setShowFinger(false)} onSuccess={() => { setShowFinger(false); setPaymentDone(true); }} speak={speak} />
        )}
      </AnimatePresence>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Assistant Screen                                                   */
/* ------------------------------------------------------------------ */

function AssistantScreen({
  t,
  speak,
  onNavigate,
  onBack,
  lang,
}: {
  t: Translations;
  speak: (text: string) => void;
  onNavigate: (s: Screen) => void;
  onBack: () => void;
  lang: Language;
}) {
  const [isListening, setIsListening] = useState(false);
  const [messages, setMessages] = useState<{ text: string; from: "user" | "bot"; typing?: boolean }[]>([
    { text: t.assistantGreeting, from: "bot" },
  ]);
  const [transcript, setTranscript] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    speak(t.assistantGreeting);
  }, [t, speak]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, isTyping]);

  const startListening = () => {
    if (typeof window === "undefined" || !(window as any).webkitSpeechRecognition) {
      speak(t.tapToSpeak);
      return;
    }
    const Recognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    const rec = new Recognition();
    rec.lang = speechLangs[lang] || "en-IN";
    rec.continuous = false;
    rec.interimResults = true;
    rec.onstart = () => setIsListening(true);
    rec.onend = () => setIsListening(false);
    rec.onresult = (e: any) => {
      const txt = Array.from(e.results).map((r: any) => r[0].transcript).join("");
      setTranscript(txt);
      if (e.results[e.results.length - 1].isFinal) {
        handleCommand(txt);
        setTranscript("");
      }
    };
    rec.start();
  };

  const handleCommand = (cmd: string) => {
    const lower = cmd.toLowerCase();
    setMessages((prev) => [...prev, { text: cmd, from: "user" }]);
    setIsTyping(true);

    const respond = (text: string, action?: () => void, delay = 1200) => {
      setTimeout(() => {
        setIsTyping(false);
        setMessages((prev) => [...prev, { text, from: "bot" }]);
        speak(text);
        if (action) setTimeout(action, 2500);
      }, delay);
    };

    // Multi-language keyword matching
    const keywords: Record<string, string[]> = {
      balance: ["balance", "saldo", "баланс", "余额", "残高", "solde", "رصيد", "बैलेंस", "బ్యాలెన్స్", "saldo"],
      transaction: ["transaction", "transação", "транзакция", "交易", "取引", "opération", "معاملة", "लेनदेन", "లావాదేవీ", "transacción"],
      electricity: ["electricity", "eletricidade", "электричество", "电", "電気", "électricité", "كهرباء", "बिजली", "విద్యుత్", "electricidad"],
      water: ["water", "água", "вода", "水", "éau", "ماء", "पानी", "నీరు", "agua"],
      gas: ["gas", "газ", "气", "ガス", "gaz", "غاز", "గ్యాస్", "gas"],
      internet: ["internet", "интернет", "网", "インターネット", "انترنت", "ఇంటర్నెట్", "internet"],
      mobile: ["mobile", "celular", "телефон", "手机", "携帯", "mobile", "جوال", "మొబైల్", "móvil"],
      insurance: ["insurance", "seguro", "страховка", "保险", "保険", "assurance", "تأمين", "బీమా", "seguro"],
      medical: ["medical", "médico", "медицина", "医疗", "医療", "médical", "طبية", "వైద్యం", "médico"],
      pay: ["pay", "pagar", "платить", "付", "支払", "payer", "دفع", "చెల్లించు", "pagar"],
      transfer: ["transfer", "transferir", "перевести", "转", "送金", "transférer", "حوّل", "బదిలీ", "transferir"],
    };

    const matches = (group: string) => keywords[group]?.some((k) => lower.includes(k));

    if (matches("balance")) {
      respond(`${t.yourBalanceIs} 24,789 ${t.rupees}.`);
    } else if (matches("transaction")) {
      respond(t.showingTransactions, () => onNavigate("home"));
    } else if (matches("electricity")) {
      respond(`${t.payingBill} ${t.electricity} ${t.bill}. ${t.pleaseConfirm}.`, () => onNavigate("bills"));
    } else if (matches("water")) {
      respond(`${t.payingBill} ${t.water} ${t.bill}. ${t.pleaseConfirm}.`, () => onNavigate("bills"));
    } else if (matches("gas")) {
      respond(`${t.payingBill} ${t.gas} ${t.bill}. ${t.pleaseConfirm}.`, () => onNavigate("bills"));
    } else if (matches("internet")) {
      respond(`${t.payingBill} ${t.internet} ${t.bill}. ${t.pleaseConfirm}.`, () => onNavigate("bills"));
    } else if (matches("mobile")) {
      respond(`${t.payingBill} ${t.mobile}. ${t.pleaseConfirm}.`, () => onNavigate("bills"));
    } else if (matches("insurance")) {
      respond(`${t.payingBill} ${t.insurance}. ${t.pleaseConfirm}.`, () => onNavigate("bills"));
    } else if (matches("medical")) {
      respond(`${t.payingBill} ${t.medical}. ${t.pleaseConfirm}.`, () => onNavigate("bills"));
    } else if (matches("pay") || matches("transfer")) {
      respond(`${t.letMeHelp} ${t.transferMoney}.`, () => onNavigate("pay"));
    } else {
      respond(`${t.understood}: "${cmd}". ${t.howCanIHelp}`);
    }
  };

  const suggested = [
    t.cmdPayElectricity, t.cmdCheckBalance, t.cmdShowTransactions,
    t.cmdPayWater, t.cmdRechargeMobile, t.cmdPayGas,
    t.cmdPayInternet, t.cmdPayInsurance, t.cmdTransferMoney,
  ];

  return (
    <div className="flex h-full flex-col pb-24">
      <div className="flex items-center gap-4 px-4 pt-4">
        <button onClick={onBack} className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white shadow-md active:scale-95">
          <ArrowLeft className="h-6 w-6 text-slate-700" />
        </button>
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-teal-100">
            <Sparkles className="h-6 w-6 text-teal-700" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">{t.assistant}</h1>
            <p className="text-sm font-semibold text-emerald-600">{t.availableNow}</p>
          </div>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4">
        <div className="mb-4 space-y-3">
          {messages.map((m, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${m.from === "user" ? "justify-end" : "justify-start"}`}
            >
              {m.from === "bot" && (
                <div className="mr-2 mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-teal-100">
                  <Sparkles className="h-4 w-4 text-teal-700" />
                </div>
              )}
              <div
                className={`max-w-[80%] rounded-2xl px-5 py-4 text-lg font-semibold ${
                  m.from === "user" ? "bg-teal-700 text-white" : "bg-white text-slate-800 shadow-md"
                }`}
              >
                {m.text}
              </div>
            </motion.div>
          ))}
          {transcript && (
            <div className="flex justify-end">
              <div className="max-w-[80%] rounded-2xl bg-teal-700/60 px-5 py-4 text-lg font-semibold text-white">
                {transcript}...
              </div>
            </div>
          )}
          {isTyping && (
            <div className="flex justify-start">
              <div className="flex items-center gap-2 rounded-2xl bg-white px-5 py-4 shadow-md">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-teal-100">
                  <Sparkles className="h-4 w-4 text-teal-700" />
                </div>
                <div className="flex gap-1">
                  <motion.div className="h-2 w-2 rounded-full bg-slate-400" animate={{ y: [0, -6, 0] }} transition={{ repeat: Infinity, duration: 0.6 }} />
                  <motion.div className="h-2 w-2 rounded-full bg-slate-400" animate={{ y: [0, -6, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.15 }} />
                  <motion.div className="h-2 w-2 rounded-full bg-slate-400" animate={{ y: [0, -6, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.3 }} />
                </div>
                <span className="text-sm font-semibold text-slate-400">{t.aiTyping}</span>
              </div>
            </div>
          )}
        </div>

        <div className="mt-4">
          <p className="mb-3 text-lg font-bold text-slate-600">{t.suggestedCommands}</p>
          <div className="flex flex-wrap gap-2">
            {suggested.map((cmd) => (
              <button
                key={cmd}
                onClick={() => handleCommand(cmd)}
                className="rounded-full bg-white px-4 py-2 text-base font-semibold text-teal-700 shadow-md active:scale-95"
              >
                {cmd}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="px-4 pb-6">
        <button
          onClick={startListening}
          className={`flex w-full items-center justify-center gap-3 rounded-2xl py-5 text-2xl font-bold text-white shadow-xl transition-all active:scale-[0.98] ${
            isListening ? "bg-rose-500 animate-pulse" : "bg-teal-700"
          }`}
        >
          {isListening ? <CircleDot className="h-8 w-8 animate-spin" /> : <Mic className="h-8 w-8" />}
          {isListening ? t.listening : t.tapToSpeak}
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Lisa Martinez Call Overlay                                         */
/* ------------------------------------------------------------------ */

function CallOverlay({
  t,
  type,
  onEnd,
}: {
  t: Translations;
  type: "video" | "voice";
  onEnd: () => void;
}) {
  const [phase, setPhase] = useState<"connecting" | "oncall">("connecting");
  const [timer, setTimer] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase("oncall"), 2500);
    return () => clearTimeout(t1);
  }, []);

  useEffect(() => {
    if (phase === "oncall") {
      const int = setInterval(() => setTimer((s) => s + 1), 1000);
      return () => clearInterval(int);
    }
  }, [phase]);

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, "0")}`;
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-900 p-6"
    >
      {type === "video" && phase === "oncall" && (
        <div className="absolute inset-0 bg-gradient-to-b from-slate-800 to-slate-900">
          <div className="flex h-full w-full items-center justify-center">
            <div className="text-center">
              <div className="mx-auto mb-4 flex h-32 w-32 items-center justify-center rounded-full bg-teal-600 text-6xl shadow-2xl">
                👩‍💼
              </div>
              <p className="text-2xl font-bold text-white">{t.lisaMartinez}</p>
              <p className="text-lg text-white/60">{t.seniorBanker}</p>
            </div>
          </div>
          {/* Self view placeholder */}
          <div className="absolute bottom-32 right-4 h-28 w-20 rounded-2xl bg-slate-700 border-2 border-white/20 flex items-center justify-center">
            <User className="h-8 w-8 text-white/40" />
          </div>
        </div>
      )}

      {type === "voice" && phase === "oncall" && (
        <div className="text-center">
          <div className="mx-auto mb-6 flex h-32 w-32 items-center justify-center rounded-full bg-teal-600 text-6xl shadow-2xl">
            👩‍💼
          </div>
          <p className="text-3xl font-bold text-white">{t.lisaMartinez}</p>
          <p className="mt-1 text-xl text-white/60">{t.seniorBanker}</p>
          <div className="mt-6 flex items-center justify-center gap-2">
            <div className="flex gap-1">
              {[0,1,2,3,4].map((i) => (
                <motion.div
                  key={i}
                  className="w-1.5 rounded-full bg-emerald-400"
                  animate={{ height: [8, 28, 12, 36, 16] }}
                  transition={{ repeat: Infinity, duration: 1.2, delay: i * 0.1 }}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {phase === "connecting" && (
        <div className="text-center">
          <motion.div
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
            className="mx-auto mb-6 flex h-32 w-32 items-center justify-center rounded-full bg-teal-600/30 text-6xl"
          >
            👩‍💼
          </motion.div>
          <p className="text-3xl font-bold text-white">{t.lisaMartinez}</p>
          <p className="mt-2 text-xl text-white/60">{t.connecting}</p>
          <motion.div
            className="mx-auto mt-6 h-1.5 w-48 rounded-full bg-white/20 overflow-hidden"
          >
            <motion.div
              className="h-full bg-teal-400"
              animate={{ x: ["-100%", "100%"] }}
              transition={{ repeat: Infinity, duration: 1.2, ease: "linear" }}
            />
          </motion.div>
        </div>
      )}

      {/* Call Controls */}
      <div className="absolute bottom-10 left-0 right-0 flex flex-col items-center gap-4">
        {phase === "oncall" && (
          <p className="text-xl font-bold text-white">{formatTime(timer)}</p>
        )}
        <div className="flex items-center gap-6">
          <button className="flex h-14 w-14 items-center justify-center rounded-full bg-white/10 text-white">
            <Mic className="h-6 w-6" />
          </button>
          <button
            onClick={onEnd}
            className="flex h-20 w-20 items-center justify-center rounded-full bg-rose-500 text-white shadow-2xl active:scale-95"
          >
            <Phone className="h-8 w-8 rotate-[135deg]" />
          </button>
          {type === "video" && (
            <button className="flex h-14 w-14 items-center justify-center rounded-full bg-white/10 text-white">
              <Video className="h-6 w-6" />
            </button>
          )}
        </div>
        <p className="text-white/50">{t.endCall}</p>
      </div>
    </motion.div>
  );
}

/* ------------------------------------------------------------------ */
/*  More / Settings Screen                                             */
/* ------------------------------------------------------------------ */

function MoreScreen({
  t,
  lang,
  setLang,
  voiceOn,
  setVoiceOn,
  speak,
  onBack,
  onLogout,
}: {
  t: Translations;
  lang: Language;
  setLang: (l: Language) => void;
  voiceOn: boolean;
  setVoiceOn: (v: boolean) => void;
  speak: (text: string) => void;
  onBack: () => void;
  onLogout: () => void;
}) {
  const [showLangPicker, setShowLangPicker] = useState(false);
  const [showCall, setShowCall] = useState<"video" | "voice" | null>(null);

  return (
    <div className="space-y-6 pb-24">
      <div className="flex items-center gap-4 px-4 pt-4">
        <button onClick={onBack} className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white shadow-md active:scale-95">
          <ArrowLeft className="h-6 w-6 text-slate-700" />
        </button>
        <h1 className="text-3xl font-bold text-slate-900">{t.settings}</h1>
      </div>

      <div className="mx-4 space-y-4">
        {/* Language */}
        <div className="rounded-3xl bg-white p-6 shadow-xl">
          <div className="mb-4 flex items-center gap-3">
            <Globe className="h-7 w-7 text-teal-700" />
            <h2 className="text-2xl font-bold text-slate-900">{t.language}</h2>
          </div>
          <button
            onClick={() => setShowLangPicker(!showLangPicker)}
            className="flex w-full items-center justify-between rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-4 text-xl font-bold text-slate-700"
          >
            <span className="flex items-center gap-3">
              <span className="text-2xl">{languageFlags[lang]}</span>
              {languageNames[lang]}
            </span>
            <ChevronDown className={`h-6 w-6 transition-transform ${showLangPicker ? "rotate-180" : ""}`} />
          </button>
          <AnimatePresence>
            {showLangPicker && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <div className="mt-3 space-y-2">
                  {(Object.keys(languageNames) as Language[]).map((l) => (
                    <button
                      key={l}
                      onClick={() => {
                        setLang(l);
                        setShowLangPicker(false);
                        const newT = translations[l];
                        speak(`${newT.languageChanged} ${languageNames[l]}`);
                      }}
                      className={`flex w-full items-center gap-3 rounded-2xl border-2 px-5 py-3 text-xl font-bold transition-all ${
                        lang === l ? "border-teal-500 bg-teal-50 text-teal-800" : "border-slate-200 bg-slate-50 text-slate-700"
                      }`}
                    >
                      <span className="text-2xl">{languageFlags[l]}</span>
                      <span>{languageNames[l]}</span>
                      {lang === l && <CheckCircle2 className="ml-auto h-5 w-5 text-teal-600" />}
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Voice Guidance */}
        <div className="rounded-3xl bg-white p-6 shadow-xl">
          <div className="mb-4 flex items-center gap-3">
            {voiceOn ? <Volume2 className="h-7 w-7 text-teal-700" /> : <VolumeX className="h-7 w-7 text-slate-400" />}
            <h2 className="text-2xl font-bold text-slate-900">{t.voiceGuidance}</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => { setVoiceOn(true); speak(t.voiceOn); }}
              className={`rounded-2xl border-2 py-4 text-xl font-bold ${voiceOn ? "border-teal-500 bg-teal-50 text-teal-800" : "border-slate-200 bg-slate-50 text-slate-600"}`}
            >
              {t.on}
            </button>
            <button
              onClick={() => { setVoiceOn(false); speak(t.voiceOff); }}
              className={`rounded-2xl border-2 py-4 text-xl font-bold ${!voiceOn ? "border-teal-500 bg-teal-50 text-teal-800" : "border-slate-200 bg-slate-50 text-slate-600"}`}
            >
              {t.off}
            </button>
          </div>
          <p className="mt-3 text-base text-slate-500">{t.speakSlowly}</p>
        </div>

        {/* Lisa Martinez - Senior Banker */}
        <div className="rounded-3xl bg-white p-6 shadow-xl">
          <h2 className="mb-4 text-2xl font-bold text-slate-900">{t.help}</h2>
          <div className="mb-4 flex items-center gap-4 rounded-2xl bg-gradient-to-r from-teal-50 to-emerald-50 p-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-teal-600 text-3xl shadow-lg">
              👩‍💼
            </div>
            <div className="flex-1">
              <p className="text-xl font-bold text-slate-900">{t.lisaMartinez}</p>
              <p className="text-base font-semibold text-teal-700">{t.seniorBanker}</p>
              <div className="mt-1 flex items-center gap-1">
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
                <span className="text-sm font-semibold text-emerald-600">{t.availableNow}</span>
              </div>
            </div>
          </div>
          <p className="mb-4 text-base text-slate-500">{t.lisaCanHelp}</p>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setShowCall("video")}
              className="flex items-center justify-center gap-2 rounded-2xl bg-violet-600 py-4 text-lg font-bold text-white shadow-lg active:scale-95"
            >
              <Video className="h-5 w-5" />
              {t.videoCall}
            </button>
            <button
              onClick={() => setShowCall("voice")}
              className="flex items-center justify-center gap-2 rounded-2xl bg-teal-700 py-4 text-lg font-bold text-white shadow-lg active:scale-95"
            >
              <PhoneCall className="h-5 w-5" />
              {t.voiceCall}
            </button>
          </div>
          <button className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl border-2 border-slate-200 py-3 text-lg font-bold text-slate-600">
            <Clock className="h-5 w-5" />
            {t.scheduleCall}
          </button>
        </div>

        {/* Help & Emergency */}
        <div className="rounded-3xl bg-white p-6 shadow-xl">
          <h2 className="mb-4 text-2xl font-bold text-slate-900">{t.instantHelp}</h2>
          <div className="space-y-3">
            <button className="flex w-full items-center gap-4 rounded-2xl bg-slate-50 p-4 text-left active:scale-[0.98]">
              <Headphones className="h-7 w-7 text-teal-700" />
              <span className="text-xl font-bold text-slate-800">{t.contactSupport}</span>
              <ChevronRight className="ml-auto h-6 w-6 text-slate-400" />
            </button>
            <button className="flex w-full items-center gap-4 rounded-2xl bg-rose-50 p-4 text-left active:scale-[0.98]">
              <AlertCircle className="h-7 w-7 text-rose-600" />
              <span className="text-xl font-bold text-rose-800">{t.callHelpline}</span>
              <ChevronRight className="ml-auto h-6 w-6 text-rose-400" />
            </button>
          </div>
        </div>

        {/* Logout */}
        <button
          onClick={onLogout}
          className="flex w-full items-center gap-4 rounded-2xl bg-white p-5 shadow-xl text-left active:scale-[0.98]"
        >
          <LogOut className="h-7 w-7 text-rose-600" />
          <span className="text-xl font-bold text-rose-700">{t.logout}</span>
        </button>
      </div>

      <AnimatePresence>
        {showCall && (
          <CallOverlay t={t} type={showCall} onEnd={() => setShowCall(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main App                                                           */
/* ------------------------------------------------------------------ */

export default function App() {
  const [authScreen, setAuthScreen] = useState<AuthScreen>("login");
  const [screen, setScreen] = useState<Screen>("home");
  const [lang, setLang] = useState<Language>("en");
  const [voiceOn, setVoiceOn] = useState(true);
  const t = translations[lang];
  const { speak, stop } = useVoice(lang);

  const safeSpeak = useCallback(
    (text: string) => { if (voiceOn) speak(text); },
    [voiceOn, speak]
  );

  useEffect(() => {
    return () => stop();
  }, [stop]);

  const handleLogin = (method: "pin" | "face" | "fingerprint") => {
    setAuthScreen("app");
    const methodText = method === "face" ? t.faceAuth : method === "fingerprint" ? t.fingerprintAuth : t.secureLogin;
    safeSpeak(`${t.welcomeBack}. ${methodText} ${t.authSuccess}.`);
  };

  const handleLogout = () => {
    setAuthScreen("login");
    setScreen("home");
    safeSpeak(t.logout);
  };

  const navItems: { key: Screen; label: string; icon: React.ReactNode }[] = [
    { key: "home", label: t.home, icon: <Home className="h-7 w-7" /> },
    { key: "pay", label: t.pay, icon: <Send className="h-7 w-7" /> },
    { key: "bills", label: t.bills, icon: <Receipt className="h-7 w-7" /> },
    { key: "assistant", label: t.assistant, icon: <Mic className="h-7 w-7" /> },
    { key: "more", label: t.more, icon: <MoreHorizontal className="h-7 w-7" /> },
  ];

  const navigate = (s: Screen) => {
    setScreen(s);
    stop();
  };

  if (authScreen !== "app") {
    return (
      <LoginScreen
        t={t}
        lang={lang}
        setLang={setLang}
        speak={safeSpeak}
        onLogin={handleLogin}
      />
    );
  }

  return (
    <div className="flex min-h-screen flex-col bg-[#FFF8F0]">
      <div className="h-safe-top" />
      <main className="flex-1 overflow-y-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={screen}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.25 }}
          >
            {screen === "home" && <HomeScreen t={t} speak={safeSpeak} onNavigate={navigate} />}
            {screen === "pay" && <PayScreen t={t} speak={safeSpeak} onBack={() => navigate("home")} />}
            {screen === "bills" && <BillsScreen t={t} speak={safeSpeak} onBack={() => navigate("home")} />}
            {screen === "assistant" && (
              <AssistantScreen t={t} speak={safeSpeak} onNavigate={navigate} onBack={() => navigate("home")} lang={lang} />
            )}
            {screen === "more" && (
              <MoreScreen
                t={t}
                lang={lang}
                setLang={setLang}
                voiceOn={voiceOn}
                setVoiceOn={setVoiceOn}
                speak={safeSpeak}
                onBack={() => navigate("home")}
                onLogout={handleLogout}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>
      <nav className="shrink-0 border-t-2 border-amber-100 bg-white px-2 pb-safe">
        <div className="flex items-center justify-around">
          {navItems.map((item) => (
            <button
              key={item.key}
              onClick={() => navigate(item.key)}
              className={`flex flex-1 flex-col items-center gap-1 py-3 transition-colors ${screen === item.key ? "text-teal-700" : "text-slate-400"}`}
            >
              <div className={`flex h-12 w-12 items-center justify-center rounded-2xl transition-all ${screen === item.key ? "bg-teal-50" : ""}`}>
                {item.icon}
              </div>
              <span className="text-sm font-bold">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
